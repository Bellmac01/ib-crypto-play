# 🎰 IB Crypto Play - Sports Betting & Casino Platform

Full-featured sports betting and casino platform with crypto wallet integration.

## 🚀 Features

- **Sports Betting** - Live matches with real-time odds
- **Casino Games** - 9 games (Aviator, Slots, Blackjack, Roulette, etc.)
- **Crypto Wallet** - BTC, ETH, SOL, BNB support
- **Fiat Conversion** - Naira ↔ Crypto conversion
- **Transaction History** - Complete audit trail

## 📋 Tech Stack

- **Backend:** FastAPI (Python)
- **Frontend:** React (HTML/JavaScript)
- **Deployment:** Render.com

## 🏃 Quick Start

### Deploy on Render.com

1. Fork this repository
2. Connect to Render.com
3. Deploy as Web Service
4. Done!

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Run server
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Access at: `http://localhost:8000`

## 🔐 Test Credentials

- **Username:** demo
- **Password:** demo123
- **Starting Balance:** ₦50,000

## 📚 API Documentation

After deployment, visit `/docs` for interactive API documentation.

Example: `https://your-app.onrender.com/docs`

## 🎮 Available Endpoints

### Authentication
- `POST /api/v1/auth/login` - User login

### Sports Betting
- `GET /api/v1/matches` - Get all matches
- `POST /api/v1/bets/place` - Place bet

### Casino
- `GET /api/v1/casino/games` - Get all games
- `POST /api/v1/casino/play` - Play game

### Crypto Wallet
- `GET /api/v1/crypto/prices` - Get crypto prices
- `POST /api/v1/wallet/convert` - Convert currency
- `POST /api/v1/wallet/withdraw` - Withdraw crypto

## 📄 License

MIT License - Feel free to use for learning and testing.

## ⚠️ Disclaimer

This is a demo/testing platform. Not for real money gambling.
